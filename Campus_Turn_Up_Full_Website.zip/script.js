const ORG_WHATSAPP="256700000000";
const EVENT_DATE=new Date(2026,1,1,19,0,0);
function updateCountdown(){
  const now=new Date();
  let diff=Math.max(0,EVENT_DATE-now);
  const d=Math.floor(diff/(1000*60*60*24));
  diff-=d*1000*60*60*24;
  const h=Math.floor(diff/(1000*60*60));
  diff-=h*1000*60*60;
  const m=Math.floor(diff/(1000*60));
  diff-=m*1000*60;
  const s=Math.floor(diff/1000);
  document.getElementById("countdown").textContent=`${d}d ${h}h ${m}m ${s}s`;
}
setInterval(updateCountdown,1000);updateCountdown();
document.getElementById("year").textContent=new Date().getFullYear();
document.getElementById("bookingForm").addEventListener("submit",function(e){
  e.preventDefault();
  const name=document.getElementById("name").value;
  const email=document.getElementById("email").value;
  const whatsapp=document.getElementById("whatsapp").value;
  const qty=document.getElementById("qty").value;
  const msg=`Hello, I am ${name}. I want ${qty} ticket(s) for Campus Turn Up Party (4th Edition). Email: ${email}, WhatsApp: ${whatsapp}`;
  window.open(`https://wa.me/${ORG_WHATSAPP}?text=${encodeURIComponent(msg)}`,"_blank");
});
